# Company Landing Page

This is Simple Product or Company Landing Website Made Using <br/>
[ReactJS](https://reactjs.org/), [Bootstrap](https://getbootstrap.com/) and also used [Sweetalert](https://sweetalert.js.org/) Library for Nice Alert Dialogs.

## UI

### HomePage
<hr />
<img src="https://user-images.githubusercontent.com/54361799/117673191-31157f00-b1c8-11eb-954e-dde3999bf295.png" />

### ServicesPage
<hr />
<img src="https://user-images.githubusercontent.com/54361799/117673300-4db1b700-b1c8-11eb-85c6-63ead81843d4.png" />

### AboutPage
<hr />
<img src="https://user-images.githubusercontent.com/54361799/117673479-75a11a80-b1c8-11eb-95d6-b17000d7d4c8.png" />


### ContactUsPage
<hr />
<img src="https://user-images.githubusercontent.com/54361799/117673607-8f426200-b1c8-11eb-8e26-741a57aa01fb.png" />
